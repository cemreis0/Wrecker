#include "SDLogHandler.h"

// Constructor implementation
SDLogHandler::SDLogHandler(const char* filename) : _filename(filename) {}

// Log info message
void SDLogHandler::info(const char* message) {
    logMessage("I:", message);
}

// Log error message
void SDLogHandler::error(const char* message) {
    logMessage("E:", message);
}

// Log data message
void SDLogHandler::data(float roll, float pitch, float yaw, float altitude, float velocity, float latitude, float longitude) {
    char buffer[128];
    snprintf(buffer, sizeof(buffer), "D:%.2f,%.2f,%.2f,%.2f,%.2f,%.6f,%.6f", roll, pitch, yaw, altitude, velocity, latitude, longitude);
    logMessage("", buffer); // Empty prefix for data messages
}

// Utility function to format and log a message
void SDLogHandler::logMessage(const char* prefix, const char* message) {
    File logFile = SD.open(_filename, FILE_WRITE);
    if (logFile) {
        // Add timestamp and a space before the message
        logFile.print(Timestamp::getCurrentTimestamp());
        logFile.print(" ");
        
        // Format and write the message
        logFile.print(prefix);
        logFile.println(message);
        
        logFile.close(); // Close the file to save the data
    }
}
