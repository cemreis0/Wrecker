#ifndef SDLOGHANDLER_H
#define SDLOGHANDLER_H

#include <Arduino.h>
#include <SD.h>
#include "Timestamp.h"

class SDLogHandler {
public:
    // Constructor: Initialize with the filename
    SDLogHandler(const char* filename);

    // Methods to log messages
    void info(const char* message);
    void error(const char* message);
    void data(float roll, float pitch, float yaw, float altitude, float velocity, float latitude, float longitude);

private:
    const char* _filename;

    // Utility function to format and log a message
    void logMessage(const char* prefix, const char* message);
};

#endif // SDLOGHANDLER_H
