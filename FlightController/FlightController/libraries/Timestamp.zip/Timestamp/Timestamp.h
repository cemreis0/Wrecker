#ifndef TIMESTAMP_H
#define TIMESTAMP_H

#include <Arduino.h>

class Timestamp {
public:
    // Method to get the current timestamp as a C-string
    static const char* getCurrentTimestamp(); // Static method to be called without an object
};

#endif // TIMESTAMP_H
