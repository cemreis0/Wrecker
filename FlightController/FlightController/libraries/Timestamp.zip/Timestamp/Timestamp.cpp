#include "Timestamp.h"

// Buffer size for timestamp
#define TIMESTAMP_BUFFER_SIZE 20

// Method to get the current timestamp as a C-string
const char* Timestamp::getCurrentTimestamp() {
    static char buffer[TIMESTAMP_BUFFER_SIZE];
    
    // Get the number of milliseconds since the Arduino started
    unsigned long milliseconds = millis();
    
    // Calculate the seconds, minutes, hours
    unsigned long seconds = milliseconds / 1000;
    unsigned long minutes = seconds / 60;
    unsigned long hours = minutes / 60;

    // Adjust each component to stay within its range
    seconds = seconds % 60;
    minutes = minutes % 60;
    hours = hours % 24;

    // Calculate the remaining milliseconds within the second
    milliseconds = milliseconds % 1000;

    // Format the timestamp as "hh:mm:ss:mm"
    snprintf(buffer, TIMESTAMP_BUFFER_SIZE, "%02lu:%02lu:%02lu:%02lu",
             hours, minutes, seconds, milliseconds / 10);

    return buffer;
}
