#include "UARTMessageHandler.h"

// Constructor implementation
UARTMessageHandler::UARTMessageHandler(HardwareSerial &serial) : _serial(serial) {}

// Send info message
void UARTMessageHandler::info(const char* message) {
    sendMessage('I', message);
}

// Send error message
void UARTMessageHandler::error(const char* message) {
    sendMessage('E', message);
}

// Send data message
void UARTMessageHandler::data(const SensorData &sensorData) {
    char buffer[30]; // 1 byte for the prefix 'D', 28 bytes for 7 floats (4 bytes each), 1 byte for line feed
    buffer[0] = 'D'; // Prefix that identifies the type of message
    memcpy(&buffer[1], &sensorData, sizeof(SensorData)); // Copy the entire struct into the buffer
    buffer[29] = 10; // Line feed (ASCII 10)
    _serial.write(buffer, sizeof(buffer)); // Write the buffer to the serial port
    _serial.flush(); // Ensure the message is fully transmitted
}

// Utility function to send a message with start and end characters
void UARTMessageHandler::sendMessage(char prefix, const char* message) {
    _serial.write(prefix); // Prefix (I or E)
    _serial.print(message); // Message content
    _serial.write(10); // End character
    _serial.flush(); // Ensure the message is fully transmitted
}